<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'chld_thm_cfg_locale_css' ) ):
    function chld_thm_cfg_locale_css( $uri ){
        if ( empty( $uri ) && is_rtl() && file_exists( get_template_directory() . '/rtl.css' ) )
            $uri = get_template_directory_uri() . '/rtl.css';
        return $uri;
    }
endif;
add_filter( 'locale_stylesheet_uri', 'chld_thm_cfg_locale_css' );

// END ENQUEUE PARENT ACTION
add_action( 'init', 'true_woo_no_breadcrumbs_storefront' );
function true_woo_no_breadcrumbs_storefront() {
	remove_action( 'storefront_before_content', 'woocommerce_breadcrumb', 10 );
}
add_action( 'init', 'true_woo_no_loops_storefront' );
function true_woo_no_loops_storefront() {
	remove_action( 'storefront_before_shop_loop', 'woocommerce_result_count', 10 );
}
// Стили
function my_styles() {
    wp_enqueue_style( 'fstore-style', get_stylesheet_uri(), array( 'bootstrap-style' ));
    wp_enqueue_style( 'bootstrap-style', get_stylesheet_directory_uri() . '/assets/css/bootstrap.min.css', array(), null, 'all' );
    wp_enqueue_style( 'fonts', get_stylesheet_directory_uri() . '/assets/fonts/fonts.css', array(), null, 'all' );
    wp_enqueue_style( 'owl-min', get_stylesheet_directory_uri() . '/assets/js/OwlCarousel2-2.3.4/dist/assets/owl.carousel.min.css', array(), null, 'all' );
    wp_enqueue_style( 'owl-default', get_stylesheet_directory_uri() . '/assets/js/OwlCarousel2-2.3.4/dist/assets/owl.theme.default.min.css', array(), null, 'all' );
}
add_action( 'wp_enqueue_scripts', 'my_styles' );

// Скрипты
function my_scripts() {
    wp_enqueue_script( 'fstore-navigation', get_stylesheet_directory_uri() . '/assets/js/navigation.js', array(), true);
    wp_enqueue_script( 'fstore-skip-link-focus-fix', get_stylesheet_directory_uri() . '/assets/js/skip-link-focus-fix.js', array(), null, true);
    wp_enqueue_script( 'bootstrap-script', get_stylesheet_directory_uri() . '/assets/js/bootstrap.min.js', array( 'jquery' ), null, true );
    wp_enqueue_script( 'owl-script', get_stylesheet_directory_uri() . '/assets/js/OwlCarousel2-2.3.4/dist/owl.carousel.min.js', array( 'jquery' ), null, true );
    wp_enqueue_script('script', get_stylesheet_directory_uri() . '/assets/js/script.js', array('jquery'), null); 
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action ( 'wp_enqueue_scripts', 'my_scripts' );

function no_primary() {
    remove_action ( 'storefront_header', 'storefront_primary_navigation', 50  );
}
add_action ( 'storefront_header', 'no_primary' );

function no_header_cart() {
    remove_action ( 'storefront_header', 'storefront_header_cart', 60 );
}
add_action ( 'storefront_header', 'no_header_cart' );

function no_branding() {
    remove_action ( 'storefront_header', 'storefront_site_branding', 20 );
}
add_action ( 'storefront_header', 'no_branding' );

function no_search() {
    remove_action ( 'storefront_header', 'storefront_product_search', 40 );
}
add_action ( 'storefront-search', 'no_search' );

